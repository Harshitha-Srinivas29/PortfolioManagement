insert into portfolio values(101);
insert into portfolio values(102);

insert into asset values(1,'AMZ',101,'Share',10);
insert into asset values(2,'GGL',101,'Share',10);
insert into asset values(3,'ABC',101,'Share',10);
insert into asset values(4,'AMZ',102,'Share',10);
insert into asset values(5,'GGL',102,'Share',10);
insert into asset values(6,'ABC',102,'Share',10);
insert into asset values(8,'SBI',101,'MF',10);
insert into asset values(7,'AXIS',101,'MF',10);

